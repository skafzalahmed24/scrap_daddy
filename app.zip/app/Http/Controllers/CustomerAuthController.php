<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Category;
use App\Models\Subcategory;
use App\Models\Order;
use App\Models\StaticPage;
use App\Models\ServicePincode;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Cache;
use App\Services\OrderPaymentService;

class CustomerAuthController extends Controller
{
    /**
     * OTPs are random in production. Locally a fixed code is used so the app
     * can be tested before an SMS provider is connected.
     */
    private function generateOtp(): string
    {
        if (config('app.static_otp')) {
            return '123456';
        }

        return str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    }

    private function logOtp(string $label, User $user, string $otp): void
    {
        if (!app()->environment('production')) {
            Log::info("OTP for {$label} (User: {$user->phone_number}): {$otp}");
        }
    }

    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'full_name' => 'required|string|max:255',
            'phone_number' => [
                'required', 'string', 'regex:/^[0-9+\-\s]{7,15}$/',
                Rule::unique('users')->where(function ($query) {
                    return $query->where('status', 1);
                })
            ],
            'password' => ['required','string','min:8','max:100','regex:/^(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).+$/'],
            'pin_code' => ['nullable', 'string', 'regex:/^[1-9][0-9]{5}$/'],
            'location' => 'nullable|string|max:255',
            'device_id' => 'nullable|string|max:255',
            'device_unique_id' => 'nullable|string|max:255',
            'device_details' => 'nullable|string',
            'platform_type' => 'required|integer|in:1,2,3',
            'referral_code' => 'nullable|string|max:12',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 0, 
                'message' => 'Validation error',
                'data' => [
                    'errors' => $validator->errors()
                ]
            ], 200);
        }

        $referrer = null;
        if ($request->filled('referral_code')) {
            $referrer = \App\Services\ReferralService::findReferrer($request->referral_code);
            if (!$referrer) {
                return response()->json([
                    'status' => 0,
                    'message' => 'This referral code is not valid.',
                    'data' => ['errors' => ['referral_code' => ['This referral code is not valid.']]],
                ], 200);
            }
        }

        $otp = $this->generateOtp();

        // Find existing deleted user to reuse the row (so DB unique constraints don't crash)
        $existingUser = User::where('status', 0)->where('phone_number', $request->phone_number)->first();

        $userData = [
            'full_name' => $request->full_name,
            'phone_number' => $request->phone_number,
            'password' => Hash::make($request->password),
            'pin_code' => $request->pin_code,
            'location' => $request->location,
            'device_id' => $request->device_id,
            'device_unique_id' => $request->device_unique_id,
            'device_details' => $request->device_details,
            'platform_type' => $request->platform_type,
            'otp' => $otp,
            'status' => 1,
            'is_verified' => false,
            'otp_expires_at' => Carbon::now()->addMinutes(10),
        ];
        if ($referrer) {
            $userData['referred_by'] = $referrer->uuid;
        }

        if ($existingUser) {
            $existingUser->update($userData);
            $user = $existingUser;
        } else {
            $user = User::create($userData);
        }

        $this->logOtp('Registration', $user, $otp);

        return response()->json([
            'status' => 1,
            'message' => 'Registration successful. Please verify your OTP to login.',
            'data' => ['user' => $user]
        ], 201);
    }

    public function verifyOtp(Request $request)
    {
        if (!$request->has('phone_number') && $request->has('login')) {
            $request->merge(['phone_number' => $request->input('login')]);
        }

        $validator = Validator::make($request->all(), [
            'phone_number' => 'required|string',
            'otp' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 0, 
                'message' => 'Validation error', 
                'data' => [
                    'errors' => $validator->errors()
                ]
            ], 200);
        }

        $user = User::where('phone_number', $request->phone_number)->first();

        if (!$user) {
            return response()->json(['status' => 0, 'message' => 'User not found'], 404);
        }

        if ($user->status == 0) {
            return response()->json([
                'status' => 0,
                'message' => 'Your account has been deleted.'
            ], 200);
        }

        if ($user->otp === null || !hash_equals((string) $user->otp, (string) $request->otp)) {
            return response()->json(['status' => 0, 'message' => 'Invalid OTP'], 400);
        }

        if (Carbon::now()->greaterThan($user->otp_expires_at)) {
            return response()->json(['status' => 0, 'message' => 'OTP has expired'], 400);
        }

        $user->update([
            'is_verified' => true,
            'otp' => null,
            'otp_expires_at' => null,
        ]);

        // If this OTP was requested through "forgot password", allow one password reset.
        if (Cache::pull('pwreset_pending:' . $user->uuid)) {
            Cache::put('pwreset_ok:' . $user->uuid, true, now()->addMinutes(15));
        }

        // Enforce single active device session by deleting old tokens
        $user->tokens()->delete();

        $accessToken = $user->createToken('auth_token', ['access'])->plainTextToken;
        $refreshToken = $user->createToken('refresh_token', ['refresh'])->plainTextToken;

        // Also log them into the web session without remember_token
        auth()->guard('web')->login($user);

        return response()->json([
            'status' => 1,
            'message' => 'OTP verified successfully.',
            'data' => [
                'access_token' => $accessToken,
                'refresh_token' => $refreshToken,
                'token_type' => 'Bearer',
                'user' => $user
            ]
        ]);
    }

    public function login(Request $request)
    {
        if (!$request->has('phone_number') && $request->has('login')) {
            $request->merge(['phone_number' => $request->input('login')]);
        }

        $validator = Validator::make($request->all(), [
            'phone_number' => 'required|string',
            'password' => 'required|string',
            'device_id' => 'nullable|string|max:255',
            'platform_type' => 'nullable|integer|in:1,2,3',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 0, 
                'message' => 'Validation error', 
                'data' => [
                    'errors' => $validator->errors()
                ]
            ], 200);
        }

        $user = User::where('phone_number', $request->phone_number)->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            return response()->json([
                'status' => 0,
                'message' => 'Invalid credentials'
            ], 401);
        }

        if ($user->status == 0) {
            return response()->json([
                'status' => 0,
                'message' => 'Your account has been deleted. Please register again or contact support.'
            ], 200);
        }

        if (!$user->is_verified) {
            $otp = $this->generateOtp();
            $user->update([
                'otp' => $otp,
                'otp_expires_at' => Carbon::now()->addMinutes(10),
            ]);
            $this->logOtp('Login Verification', $user, $otp);
            
            return response()->json([
                'status' => 0,
                'message' => 'Please verify your account first. A new OTP has been sent.',
                'data' => ['requires_verification' => true]
            ], 200);
        }

        if ($request->has('device_id') || $request->has('platform_type')) {
            $user->update([
                'device_id' => $request->device_id ?? $user->device_id,
                'platform_type' => $request->platform_type ?? $user->platform_type,
            ]);
        }

        // Enforce single active device session by deleting old tokens
        $user->tokens()->delete();

        $accessToken = $user->createToken('auth_token', ['access'])->plainTextToken;
        $refreshToken = $user->createToken('refresh_token', ['refresh'])->plainTextToken;

        // Also log them into the web session
        auth()->guard('web')->login($user);

        return response()->json([
            'status' => 1,
            'message' => 'Login successful',
            'data' => [
                'access_token' => $accessToken,
                'refresh_token' => $refreshToken,
                'token_type' => 'Bearer',
                'user' => $user
            ]
        ]);
    }

    public function forgotPassword(Request $request)
    {
        if (!$request->has('phone_number') && $request->has('login')) {
            $request->merge(['phone_number' => $request->input('login')]);
        }

        $validator = Validator::make($request->all(), [
            'phone_number' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 0, 
                'message' => 'Validation error', 
                'data' => [
                    'errors' => $validator->errors()
                ]
            ], 200);
        }

        $user = User::where('phone_number', $request->phone_number)->first();

        if (!$user || $user->status == 0) {
            return response()->json(['status' => 0, 'message' => 'User not found'], 404);
        }

        $otp = $this->generateOtp();
        $user->update([
            'otp' => $otp,
            'otp_expires_at' => Carbon::now()->addMinutes(10),
        ]);
        Cache::put('pwreset_pending:' . $user->uuid, true, now()->addMinutes(10));

        $this->logOtp('Forgot Password', $user, $otp);

        return response()->json([
            'status' => 1,
            'message' => 'OTP sent successfully for password reset.'
        ]);
    }

    public function resetPassword(Request $request)
    {
        if (!$request->has('phone_number') && $request->has('login')) {
            $request->merge(['phone_number' => $request->input('login')]);
        }

        $validator = Validator::make($request->all(), [
            'phone_number' => 'required|string',
            'otp' => 'nullable|string|size:6',
            'password' => ['required','string','min:8','max:100','regex:/^(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).+$/','confirmed'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 0, 
                'message' => 'Validation error', 
                'data' => [
                    'errors' => $validator->errors()
                ]
            ], 200);
        }

        $user = User::where('phone_number', $request->phone_number)->first();

        if (!$user || $user->status == 0) {
            return response()->json(['status' => 0, 'message' => 'User not found'], 404);
        }

        // Proof of phone ownership: either a valid OTP in this request (website)
        // or an OTP already verified through /verify-otp (mobile app).
        $otpOk = $request->filled('otp')
            && $user->otp !== null
            && hash_equals((string) $user->otp, (string) $request->otp)
            && $user->otp_expires_at
            && Carbon::now()->lessThanOrEqualTo($user->otp_expires_at);

        $verifiedEarlier = Cache::pull('pwreset_ok:' . $user->uuid);

        if (!$otpOk && !$verifiedEarlier) {
            return response()->json(['status' => 0, 'message' => 'OTP verification is required to reset the password.'], 400);
        }

        Cache::forget('pwreset_pending:' . $user->uuid);

        $user->update([
            'password' => Hash::make($request->password),
            'otp' => null,
            'otp_expires_at' => null,
            'is_verified' => true, // verify them if they weren't already
        ]);

        return response()->json([
            'status' => 1,
            'message' => 'Password reset successfully. You can now login.'
        ]);
    }

    public function changePassword(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'old_password' => 'required|string',
            'new_password' => ['required','string','min:8','max:100','regex:/^(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).+$/','confirmed','different:old_password'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 0, 
                'message' => 'Validation error', 
                'data' => [
                    'errors' => $validator->errors()
                ]
            ], 200);
        }

        $user = $request->user();

        if (!Hash::check($request->old_password, $user->password)) {
            return response()->json(['status' => 0, 'message' => 'Old password does not match'], 400);
        }

        $user->update([
            'password' => Hash::make($request->new_password)
        ]);

        return response()->json([
            'status' => 1,
            'message' => 'Password changed successfully.'
        ]);
    }

    public function user(Request $request)
    {
        return response()->json([
            'status' => 1,
            'message' => 'User fetched successfully',
            'data' => [
                'user' => $request->user()
            ]
        ]);
    }

    public function refreshToken(Request $request)
    {
        if (!$request->user()->currentAccessToken()->can('refresh')) {
            return response()->json([
                'status' => 0,
                'message' => 'Invalid refresh token.'
            ], 200);
        }
        
        $request->user()->currentAccessToken()->delete(); // Revoke current refresh token
        
        $accessToken = $request->user()->createToken('auth_token', ['access'])->plainTextToken;
        $refreshToken = $request->user()->createToken('refresh_token', ['refresh'])->plainTextToken;
        
        return response()->json([
            'status' => 1,
            'message' => 'Tokens refreshed successfully.',
            'data' => [
                'access_token' => $accessToken,
                'refresh_token' => $refreshToken,
                'token_type' => 'Bearer'
            ]
        ]);
    }

    public function updateProfile(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'full_name' => 'nullable|string|min:2|max:255',
            'phone_number' => [
                'nullable', 'string', 'regex:/^[0-9+\-\s]{7,15}$/',
                Rule::unique('users', 'phone_number')->ignore($request->user()->uuid, 'uuid')->where('status', 1),
            ],
            'email' => ['nullable', 'email', 'max:255', Rule::unique('users', 'email')->ignore($request->user()->uuid, 'uuid')],
            'pin_code' => ['nullable', 'string', 'regex:/^[1-9][0-9]{5}$/'],
            'location' => 'nullable|string|max:255',
            'profile_image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:5120',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 0, 
                'message' => 'Validation error', 
                'data' => [
                    'errors' => $validator->errors()
                ]
            ], 200);
        }

        $user = $request->user();
        $data = $request->only(['full_name', 'phone_number', 'email', 'pin_code', 'location']);
        
        if ($request->hasFile('profile_image')) {
            $image = $request->file('profile_image');
            $imageName = time() . '_' . Str::random(10) . '.' . ($image->extension() ?: 'jpg');
            $targetDir = public_path('profiles');
            
            if (!File::exists($targetDir)) {
                File::makeDirectory($targetDir, 0755, true);
            }
            
            $targetPath = $targetDir . '/' . $imageName;
            file_put_contents($targetPath, file_get_contents($image->getRealPath()));
            @chmod($targetPath, 0644);
            
            // Delete old profile image if it exists
            if ($user->profile_image && File::exists(public_path($user->profile_image))) {
                File::delete(public_path($user->profile_image));
            }
            
            $data['profile_image'] = 'profiles/' . $imageName;
        }
        
        $user->update($data);
        
        return response()->json([
            'status' => 1,
            'message' => 'Profile updated successfully!',
            'data' => [
                'user' => $user
            ]
        ]);
    }


    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        // Also logout from web session
        auth()->guard('web')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return response()->json([
            'status' => 1,
            'message' => 'Logged out successfully.'
        ]);
    }

    public function deleteAccount(Request $request)
    {
        $user = $request->user();
        $user->tokens()->delete();
        $user->update(['status' => 0]);

        // Also logout from web session
        auth()->guard('web')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return response()->json([
            'status' => 1,
            'message' => 'Account deleted successfully.'
        ]);
    }

    // --- CATEGORY METHODS ---
    public function categories(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'search' => 'nullable|string',
            'min' => 'nullable|integer|min:0',
            'max' => 'nullable|integer|min:1'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 0,
                'message' => 'Validation error',
                'data' => [
                    'errors' => $validator->errors()
                ]
            ], 200);
        }

        $query = Category::where('status', 1);

        if ($request->has('search') && !empty($request->search)) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('title', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%");
            });
        }

        $total_count = $query->count();

        if ($request->has('min') && is_numeric($request->min)) {
            $query->offset((int)$request->min);
        }
        
        if ($request->has('max') && is_numeric($request->max)) {
            $query->limit((int)$request->max);
        }

        $categories = $query->orderBy('created_at', 'desc')->get();

        return response()->json([
            'status' => 1,
            'message' => 'Categories fetched successfully',
            'data' => [
                'count' => $total_count,
                'rows' => $categories
            ]
        ]);
    }

    // --- SUBCATEGORY METHODS ---
    public function subcategories(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'category_uuid' => 'nullable|exists:categories,uuid',
            'search' => 'nullable|string',
            'sort' => 'nullable|string|in:asc,desc',
            'min' => 'nullable|integer|min:0',
            'max' => 'nullable|integer|min:1'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 0,
                'message' => 'Validation error',
                'data' => [
                    'errors' => $validator->errors()
                ]
            ], 200);
        }

        $query = Subcategory::where('status', 1);
        
        if ($request->filled('category_uuid')) {
            $query->where('category_id', $request->category_uuid);
        }

        if ($request->has('search') && !empty($request->search)) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%");
            });
        }

        $total_count = $query->count();

        $sort = 'asc';
        if ($request->has('sort') && in_array(strtolower($request->sort), ['asc', 'desc'])) {
            $sort = strtolower($request->sort);
        }
        $query->orderBy('name', $sort);

        if ($request->has('min') && is_numeric($request->min)) {
            $query->offset((int)$request->min);
        }
        if ($request->has('max') && is_numeric($request->max)) {
            $query->limit((int)$request->max);
        }

        $subcategories = $query->get();

        return response()->json([
            'status' => 1,
            'message' => 'Subcategories fetched successfully',
            'data' => [
                'count' => $total_count,
                'rows' => $subcategories
            ]
        ]);
    }

    // --- ORDER METHODS ---
    public function createOrder(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'items' => 'required|array|min:1',
            'items.*.subcategory_uuid' => 'required|exists:subcategories,uuid',
            'items.*.quantity' => 'required|integer|min:1|max:100000',
            'items.*.name' => 'required|string|max:255',
            'pickup_location' => 'required|string|max:500',
            'pin_code' => 'required|string',
            'pickup_date' => 'required|date|after_or_equal:today',
            'pickup_time' => 'required|string|max:50',
            'notes' => 'nullable|string|max:1000',
            'images' => 'nullable|array|max:10',
            'images.*' => 'string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 0,
                'message' => 'Validation error',
                'data' => [
                    'errors' => $validator->errors()
                ]
            ], 200);
        }

        $pin = trim((string) $request->pin_code);
        if (!preg_match(ServicePincode::FORMAT, $pin) || !ServicePincode::isServiceable($pin)) {
            return response()->json([
                'status' => 0,
                'message' => preg_match(ServicePincode::FORMAT, $pin)
                    ? ServicePincode::unavailableMessage($pin)
                    : 'Please enter a valid 6-digit PIN code for the pickup address.',
            ], 200);
        }

        $firstSubcategory = Subcategory::find($request->items[0]['subcategory_uuid']);

        $order = new Order();
        $order->user_uuid = $request->user()->uuid;
        $order->category_uuid = $firstSubcategory ? $firstSubcategory->category_id : null;
        $order->items = $request->items;
        $order->status = 'pending';
        $order->pickup_location = $request->pickup_location;
        $order->pin_code = $pin;
        $order->pickup_date = $request->pickup_date;
        $order->pickup_time = $request->pickup_time;
        $order->notes = $request->notes;

        $order->images = $request->images ?? [];
        $order->save();

        return response()->json([
            'status' => 1,
            'message' => 'Order created successfully',
            'data' => $order
        ], 201);
    }

    public function orders(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'min' => 'nullable|integer|min:0',
            'max' => 'nullable|integer|min:1'
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 0, 'message' => 'Validation error', 'data' => [
                'errors' => $validator->errors()
            ]
        ], 422);
        }

        $query = Order::with(['category', 'subcategory'])
                       ->where('user_uuid', $request->user()->uuid);

        $total_count = $query->count();

        $query->orderBy('created_at', 'desc');

        if ($request->has('min') && is_numeric($request->min)) {
            $query->offset((int)$request->min);
        }
        if ($request->has('max') && is_numeric($request->max)) {
            $query->limit((int)$request->max);
        }

        $orders = $query->get()->toArray();

        foreach ($orders as &$order) {
            if (!empty($order['pickup_date'])) {
                $date = \Carbon\Carbon::parse($order['pickup_date']);
                if ($date->isToday()) {
                    $order['pickup_date'] = 'Today';
                } elseif ($date->isTomorrow()) {
                    $order['pickup_date'] = 'Tomorrow';
                } else {
                    $order['pickup_date'] = $date->format('Y-m-d');
                }
            }
        }

        return response()->json([
            'status' => 1,
            'message' => 'Orders fetched successfully',
            'data' => [
                'count' => $total_count,
                'rows' => $orders
            ]
        ]);
    }

    public function showOrder(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'order_id' => 'required|integer'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 0,
                'message' => 'Validation error',
                'data' => [
                    'errors' => $validator->errors()
                ]
            ], 200);
        }

        $order = Order::with(['category', 'subcategory'])
                      ->where('user_uuid', $request->user()->uuid)
                      ->where('id', $request->order_id)
                      ->first();

        if (!$order) {
            return response()->json(['status' => 0, 'message' => 'Order not found'], 404);
        }

        return response()->json([
            'status' => 1,
            'message' => 'Order details fetched successfully',
            'data' => $order
        ]);
    }

    public function payments(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'min' => 'nullable|integer|min:0',
            'max' => 'nullable|integer|min:1'
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 0, 'message' => 'Validation error', 'data' => [
                'errors' => $validator->errors()
            ]
        ], 422);
        }

        $query = Order::where('user_uuid', $request->user()->uuid)
                       ->where(function ($q) {
                           $q->whereNotNull('payment_id')
                             ->orWhere('payment_status', '!=', 'pending');
                       })
                       ->orderBy('created_at', 'desc');

        $total_count = $query->count();

        if ($request->has('min') && is_numeric($request->min)) {
            $query->offset((int)$request->min);
        }
        if ($request->has('max') && is_numeric($request->max)) {
            $query->limit((int)$request->max);
        }

        $orders = $query->get(['id', 'total_amount', 'payment_status', 'payment_id', 'created_at']);

        return response()->json([
            'status' => 1,
            'message' => 'Payments fetched successfully',
            'data' => [
                'count' => $total_count,
                'rows' => $orders
            ]
        ]);
    }

    // --- STATIC PAGE METHODS ---
    public function page(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'type' => 'required|string'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 0,
                'message' => 'Validation error',
                'data' => [
                    'errors' => $validator->errors()
                ]
            ], 200);
        }

        $type = $request->type;
        $page = StaticPage::where('slug', $type)
                          ->orWhere('title', str_replace('-', ' ', $type))
                          ->first();

        if (!$page) {
            return response()->json(['status' => 0, 'message' => 'Page not found'], 404);
        }

        return response()->json([
            'status' => 1,
            'message' => 'Page fetched successfully',
            'data' => $page
        ]);
    }

    // --- SERVICE AREA CHECK ---
    public function checkPincode(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'pin_code' => ['required', 'string', 'regex:/^[1-9][0-9]{5}$/'],
        ], [
            'pin_code.regex' => 'Please enter a valid 6-digit PIN code.',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 0,
                'message' => $validator->errors()->first(),
                'data' => ['serviceable' => false],
            ], 200);
        }

        $pin = $request->pin_code;
        $ok = ServicePincode::isServiceable($pin);
        $row = ServicePincode::where('pin_code', $pin)->first();

        return response()->json([
            'status' => 1,
            'message' => $ok ? "Pickup service is available in {$pin}." : ServicePincode::unavailableMessage($pin),
            'data' => [
                'pin_code' => $pin,
                'serviceable' => $ok,
                'area' => $row->area ?? null,
                'city' => $row->city ?? null,
            ],
        ]);
    }

    // --- HOME METHOD ---
    public function home(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'user_id' => 'nullable|string',
            'pin_code' => 'nullable|string|max:10',
            'type' => 'nullable|string|in:web,mobile'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 0,
                'message' => 'Validation error',
                'data' => [
                    'errors' => $validator->errors()
                ]
            ], 200);
        }

        // Fetch Banners (Default to mobile banners for customer app API)
        $bannerType = $request->type ?? 'mobile';
        $banners = \App\Models\Banner::where('status', 1)
            ->where('type', $bannerType)
            ->orderBy('created_at', 'desc')
            ->take(5)
            ->get();

        if ($banners->isEmpty() && !$request->has('type')) {
            $banners = \App\Models\Banner::where('status', 1)->orderBy('created_at', 'desc')->take(5)->get();
        }

        // Live pickups are private: only for the owner of the bearer token.
        $authUser = $request->user('sanctum');
        $livePickups = $authUser
            ? Order::with(['category', 'subcategory'])
                ->where('user_uuid', $authUser->uuid)
                ->whereNotIn('status', ['completed', 'cancelled', 'rejected'])
                ->orderBy('created_at', 'desc')
                ->take(5)
                ->get()->toArray()
            : [];
            
        foreach ($livePickups as &$order) {
            if (!empty($order['pickup_date'])) {
                $date = Carbon::parse($order['pickup_date']);
                if ($date->isToday()) {
                    $order['pickup_date'] = 'Today';
                } elseif ($date->isTomorrow()) {
                    $order['pickup_date'] = 'Tomorrow';
                } else {
                    $order['pickup_date'] = $date->format('Y-m-d');
                }
            }
        }

        // Fetch Categories
        $categories = \App\Models\Category::where('status', 1)->take(6)->get();

        // Is pickup available at the PIN code detected by the app?
        $serviceAvailable = null;
        $serviceMessage = null;
        if ($request->filled('pin_code')) {
            $homePin = trim((string) $request->pin_code);
            $serviceAvailable = preg_match(ServicePincode::FORMAT, $homePin) && ServicePincode::isServiceable($homePin);
            $serviceMessage = $serviceAvailable
                ? "Pickup service is available in {$homePin}."
                : ServicePincode::unavailableMessage(preg_match(ServicePincode::FORMAT, $homePin) ? $homePin : null);
        }

        return response()->json([
            'status' => 1,
            'message' => 'Home data fetched successfully',
            'data' => [
                'banners' => $banners,
                'live_pickups' => $livePickups,
                'categories' => $categories,
                'service_available' => $serviceAvailable,
                'service_message' => $serviceMessage,
            ]
        ]);
    }

    // --- BANNERS METHODS ---
    public function banners(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'type' => 'nullable|string|in:web,mobile',
            'min' => 'nullable|integer|min:0',
            'max' => 'nullable|integer|min:1'
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 0,
                'message' => 'Validation error',
                'data' => [
                    'errors' => $validator->errors()
                ]
            ], 200);
        }

        $query = \App\Models\Banner::where('status', 1);

        if ($request->has('type') && !empty($request->type)) {
            $query->where('type', $request->type);
        } else {
            // Default to mobile banners for customer API if available
            $hasMobile = (clone $query)->where('type', 'mobile')->exists();
            if ($hasMobile) {
                $query->where('type', 'mobile');
            }
        }

        $total_count = $query->count();

        if ($request->has('min') && is_numeric($request->min)) {
            $query->offset((int)$request->min);
        }
        
        if ($request->has('max') && is_numeric($request->max)) {
            $query->limit((int)$request->max);
        }

        $banners = $query->orderBy('created_at', 'desc')->get();

        return response()->json([
            'status' => 1,
            'message' => 'Banners fetched successfully',
            'data' => [
                'count' => $total_count,
                'rows' => $banners
            ]
        ]);
    }
    // --- FAQS METHOD ---
    public function faqs(Request $request)
    {
        $faqs = \App\Models\Faq::where('status', 1)->get();

        return response()->json([
            'status' => 1,
            'message' => 'FAQs fetched successfully',
            'data' => $faqs
        ]);
    }

    // --- PAYMENTS & REWARDS METHODS ---
    public function verifyPayment(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'order_id' => 'required|integer',
            'razorpay_payment_id' => 'required|string|max:100',
            'razorpay_order_id' => 'nullable|string|max:100',
            'razorpay_signature' => 'nullable|string|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 0,
                'message' => 'Validation error',
                'data' => ['errors' => $validator->errors()]
            ], 200);
        }

        $order = Order::where('user_uuid', $request->user()->uuid)
                      ->where('id', $request->order_id)
                      ->first();

        if (!$order) {
            return response()->json(['status' => 0, 'message' => 'Order not found'], 404);
        }

        if ($order->payment_status === 'completed') {
            return response()->json(['status' => 1, 'message' => 'Payment already completed', 'data' => $order]);
        }

        if (OrderPaymentService::payableAmount($order) <= 0) {
            return response()->json(['status' => 0, 'message' => 'Order amount is not set yet.'], 200);
        }

        $error = OrderPaymentService::verifyRazorpayPayment(
            $order,
            $request->razorpay_payment_id,
            $request->razorpay_order_id,
            $request->razorpay_signature
        );

        if ($error) {
            return response()->json(['status' => 0, 'message' => $error], 200);
        }

        $order = OrderPaymentService::markPaid($order, $request->razorpay_payment_id);

        return response()->json([
            'status' => 1,
            'message' => 'Payment status updated successfully',
            'data' => $order
        ]);
    }

    public function getRewardSettings(Request $request)
    {
        $user = $request->user();
        $coinValue = OrderPaymentService::coinValue();
        $coins = (int) ($user->reward_coins ?? 0);

        return response()->json([
            'status' => 1,
            'message' => 'Reward settings fetched successfully',
            'data' => [
                'reward_coins' => $coins,
                'coin_value_in_rupees' => $coinValue,
                'total_value_in_rupees' => $coins * $coinValue
            ]
        ]);
    }

    public function redeemCoins(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'order_id' => 'required|integer',
            'coins' => 'required|integer|min:1',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 0,
                'message' => 'Validation error',
                'data' => ['errors' => $validator->errors()]
            ], 200);
        }

        $user = $request->user();

        $order = Order::where('user_uuid', $user->uuid)
                      ->where('id', $request->order_id)
                      ->first();

        if (!$order) {
            return response()->json(['status' => 0, 'message' => 'Order not found'], 404);
        }

        if ($order->payment_status === 'completed') {
            return response()->json(['status' => 0, 'message' => 'Payment is already completed.'], 200);
        }

        if (($user->reward_coins ?? 0) < $request->coins) {
            return response()->json(['status' => 0, 'message' => 'Insufficient reward coins.'], 200);
        }

        if ((float) ($order->total_amount ?? 0) <= 0) {
            return response()->json(['status' => 0, 'message' => 'Order amount is not set yet.'], 200);
        }

        [$used, $discount] = OrderPaymentService::redeemCoins($user, $order, (int) $request->coins);

        if ($used <= 0) {
            return response()->json(['status' => 0, 'message' => 'Rewards cannot be applied to this order.'], 200);
        }

        $order->refresh();
        $user->refresh();

        return response()->json([
            'status' => 1,
            'message' => 'Coins redeemed successfully.',
            'data' => [
                'order' => $order,
                'payable_amount' => OrderPaymentService::payableAmount($order),
                'remaining_coins' => (int) $user->reward_coins
            ]
        ]);
    }

    public function collectCoins(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'order_id' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 0,
                'message' => 'Validation error',
                'data' => ['errors' => $validator->errors()]
            ], 200);
        }

        $user = $request->user();

        $order = Order::where('user_uuid', $user->uuid)
                      ->where('id', $request->order_id)
                      ->first();

        if (!$order) {
            return response()->json(['status' => 0, 'message' => 'Order not found'], 404);
        }

        // Coins are only credited once the payment is really completed
        // (see OrderPaymentService::markPaid) - never twice.
        if ($order->payment_status !== 'completed') {
            return response()->json([
                'status' => 0,
                'message' => 'Coins are credited after the payment is completed.'
            ], 200);
        }

        $user->refresh();

        return response()->json([
            'status' => 1,
            'message' => 'Coins collected successfully.',
            'data' => [
                'coins_earned' => (int) $order->coins_earned,
                'total_coins' => (int) $user->reward_coins
            ]
        ]);
    }
}
