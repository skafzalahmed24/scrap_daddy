<?php

namespace App\Http\Controllers;

use App\Models\Banner;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class BannerController extends Controller
{
    public function index(Request $request)
    {
        $query = Banner::query();
        
        if ($request->has('search') && !empty($request->search)) {
            $query->where('title', 'like', '%' . $request->search . '%');
        }

        if ($request->has('type') && !empty($request->type)) {
            $query->where('type', $request->type);
        }

        $banners = $query->latest()->paginate(10);
        return response()->json($banners);
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'short_description' => 'nullable|string',
            'status' => 'required|boolean',
            'type' => 'required|string|in:web,mobile',
            'uploads' => 'nullable|file|mimes:jpeg,png,jpg,gif,svg,mp4,webm,ogg|max:20480', // 20MB max
        ]);

        $data = $request->only(['title', 'short_description', 'status', 'type']);

        if ($request->hasFile('uploads')) {
            $file = $request->file('uploads');
            $extension = ($file->extension() ?: 'jpg');
            $filename = time() . '_' . Str::random(10) . '.' . $extension;
            
            $targetDir = public_path('uploads/banners');
            if (!file_exists($targetDir)) {
                mkdir($targetDir, 0755, true);
            }
            
            $targetPath = $targetDir . '/' . $filename;
            file_put_contents($targetPath, file_get_contents($file->getRealPath()));
            @chmod($targetPath, 0644);
            
            $data['uploads'] = 'uploads/banners/' . $filename;
        }

        $banner = Banner::create($data);

        return response()->json(['message' => 'Banner created successfully', 'banner' => $banner]);
    }

    public function show(string $id)
    {
        $banner = Banner::findOrFail($id);
        return response()->json($banner);
    }

    public function update(Request $request, string $id)
    {
        $banner = Banner::findOrFail($id);

        $request->validate([
            'title' => 'required|string|max:255',
            'short_description' => 'nullable|string',
            'status' => 'required|boolean',
            'type' => 'required|string|in:web,mobile',
            'uploads' => 'nullable|file|mimes:jpeg,png,jpg,gif,svg,mp4,webm,ogg|max:20480',
        ]);

        $data = $request->only(['title', 'short_description', 'status', 'type']);

        if ($request->hasFile('uploads')) {
            $file = $request->file('uploads');
            $extension = ($file->extension() ?: 'jpg');
            $filename = time() . '_' . Str::random(10) . '.' . $extension;
            
            $targetDir = public_path('uploads/banners');
            if (!file_exists($targetDir)) {
                mkdir($targetDir, 0755, true);
            }
            
            $targetPath = $targetDir . '/' . $filename;
            file_put_contents($targetPath, file_get_contents($file->getRealPath()));
            @chmod($targetPath, 0644);
            
            // Delete old file if exists
            if ($banner->uploads && file_exists(public_path($banner->uploads))) {
                @unlink(public_path($banner->uploads));
            }

            $data['uploads'] = 'uploads/banners/' . $filename;
        }

        $banner->update($data);

        return response()->json(['message' => 'Banner updated successfully', 'banner' => $banner]);
    }

    public function destroy(string $id)
    {
        $banner = Banner::findOrFail($id);
        
        if ($banner->uploads && file_exists(public_path($banner->uploads))) {
            @unlink(public_path($banner->uploads));
        }
        
        $banner->delete();

        return response()->json(['message' => 'Banner deleted successfully']);
    }

    public function toggleStatus(Request $request, string $id)
    {
        $banner = Banner::findOrFail($id);
        
        $request->validate([
            'status' => 'required|boolean'
        ]);

        $banner->update(['status' => $request->status]);

        return response()->json(['message' => 'Status updated successfully', 'banner' => $banner]);
    }
}
