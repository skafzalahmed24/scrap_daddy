<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\FeedbackController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\PaymentController;

Route::get('/', [HomeController::class, 'index']);
// The old "Category Explorer" page is gone: categories open the pickup page directly (category chips + items).
Route::get('/explore-categories', fn () => redirect()->route('customer.orders.create'))->name('categories.explore');
Route::get('/category/{id}', fn ($id) => redirect()->route('customer.orders.create', ['category' => $id]))->name('category.show');

Route::get('/admin/login', function () {
    if (session('is_admin')) {
        return redirect('/dashboard');
    }

    return view('login');
});

Route::post('/admin/logout', [\App\Http\Controllers\AuthController::class, 'logout'])->name('admin.logout');

use App\Http\Controllers\AdminDashboardController;
use App\Http\Controllers\AdminPaymentController;
use App\Http\Controllers\AdminUserController;

Route::middleware('admin')->group(function () {
Route::get('/dashboard', [AdminDashboardController::class, 'index'])->name('dashboard');
Route::get('/admin/payments', [AdminPaymentController::class, 'index'])->name('admin.payments.index');
Route::get('/admin/users', [AdminUserController::class, 'index'])->name('admin.users.index');
Route::get('/admin/users/{uuid}', [AdminUserController::class, 'show'])->name('admin.users.show');
});

Route::get('/customer/login', function () {
    return view('customer-login');
});

Route::get('/customer/register', function () {
    return view('customer-register');
});

Route::get('/customer/verify-otp', function () {
    return view('customer-verify-otp');
});

Route::get('/customer/forgot-password', function () {
    return view('customer-forgot-password');
});

Route::get('/customer/reset-password', function () {
    return view('customer-reset-password');
});

Route::get('/customer/logout-web', function () {
    auth()->guard('web')->logout();
    session()->invalidate();
    session()->regenerateToken();
    return redirect('/customer/login');
});

Route::middleware(['auth'])->group(function () {
    Route::get('/customer/home', function () {
        return view('customer.home');
    })->name('customer.home');

    Route::get('/customer/categories', [\App\Http\Controllers\HomeController::class, 'categories'])->name('customer.categories');

    Route::get('/customer/support', [\App\Http\Controllers\SupportController::class, 'supportPage'])->name('customer.support');
    Route::post('/customer/support/ticket', [\App\Http\Controllers\SupportController::class, 'webCreateTicket'])->name('customer.support.ticket');
    Route::get('/customer/refer', [\App\Http\Controllers\SupportController::class, 'referPage'])->name('customer.refer');

    Route::get('/customer/rewards', function () {
        return view('customer.rewards');
    })->name('customer.rewards');

    Route::get('/customer/profile', function () {
        return view('customer.profile');
    })->name('customer.profile');

    Route::post('/customer/profile/update', [\App\Http\Controllers\CustomerAuthController::class, 'updateProfile'])->name('customer.profile.update');

    Route::get('/customer/payments', function () {
        return view('customer.payments');
    })->name('customer.payments');

    Route::get('/customer/faqs', [\App\Http\Controllers\HomeController::class, 'faqs'])->name('customer.faqs');

    Route::get('/customer/change-password', function () {
        return view('customer.change-password');
    })->name('customer.change-password');

    // User Orders & Feedback
    Route::get('/customer/orders', [OrderController::class, 'index'])->name('customer.orders');
    Route::get('/customer/order/{id}', [OrderController::class, 'show'])->name('customer.order.show');
    Route::get('/customer/request-pickup', [OrderController::class, 'create'])->name('customer.orders.create');
    Route::post('/customer/orders', [OrderController::class, 'store'])->name('customer.orders.store');
    Route::post('/customer/orders/{id}/cancel', [OrderController::class, 'cancel'])->name('customer.orders.cancel');
    Route::post('/customer/feedback', [FeedbackController::class, 'store'])->name('customer.feedback.store');

    // Scrap Vehicles Web Routes
    Route::get('/customer/scrap-vehicles', function () {
        return view('customer.scrap_vehicles');
    })->name('customer.scrap_vehicles');
    Route::post('/customer/scrap-vehicles', [\App\Http\Controllers\ScrapVehicleController::class, 'store'])->name('customer.scrap_vehicles.store');

    // Payments
    Route::get('/customer/payment/{orderId}', [PaymentController::class, 'initiatePayment'])->name('customer.payment.initiate');
    Route::post('/customer/payment/{orderId}/apply-rewards', [PaymentController::class, 'applyRewards'])->name('customer.payment.apply-rewards');
    Route::post('/customer/payment/callback', [PaymentController::class, 'paymentCallback'])->name('customer.payment.callback');
});

// Static Pages
Route::get('/page/{slug}', [PageController::class, 'show'])->name('page.show');

Route::middleware('admin')->group(function () {
// "Service not available in my area" requests + admin notification feed
Route::get('/admin/service-requests', [\App\Http\Controllers\ServiceRequestController::class, 'adminIndex'])->name('admin.service-requests.index');
Route::post('/admin/service-requests/{id}/status', [\App\Http\Controllers\ServiceRequestController::class, 'adminUpdateStatus'])->name('admin.service-requests.status');
Route::delete('/admin/service-requests/{id}', [\App\Http\Controllers\ServiceRequestController::class, 'adminDestroy'])->name('admin.service-requests.destroy');
Route::get('/admin/notifications', [\App\Http\Controllers\ServiceRequestController::class, 'adminNotifications'])->name('admin.notifications');

// Site settings (address, contact, social links)
Route::get('/admin/settings', [\App\Http\Controllers\AdminSettingsController::class, 'index'])->name('admin.settings.index');
Route::post('/admin/settings', [\App\Http\Controllers\AdminSettingsController::class, 'update'])->name('admin.settings.update');

// Categories Admin View
Route::get('/admin/categories', function () {
    return view('admin.categories');
});

Route::get('/admin/subcategories', function () {
    return view('admin.subcategories');
});

Route::get('/admin/banners', function () {
    return view('admin.banners');
});

Route::get('/admin/faqs', function () {
    return view('admin.faqs');
});

Route::get('/admin/rewards', function () {
    return view('admin.rewards');
});

// Admin Orders, Feedback & Pages
Route::get('/admin/orders', [OrderController::class, 'adminIndex'])->name('admin.orders.index');
Route::post('/admin/orders/{id}/status', [OrderController::class, 'updateStatus'])->name('admin.orders.status');

Route::get('/admin/tickets', [App\Http\Controllers\AdminTicketController::class, 'index'])->name('admin.tickets.index');
Route::post('/admin/tickets/{id}', [App\Http\Controllers\AdminTicketController::class, 'update'])->name('admin.tickets.update');

Route::get('/admin/pincodes', [App\Http\Controllers\AdminPincodeController::class, 'index'])->name('admin.pincodes.index');
Route::post('/admin/pincodes', [App\Http\Controllers\AdminPincodeController::class, 'store'])->name('admin.pincodes.store');
Route::post('/admin/pincodes/{id}/toggle', [App\Http\Controllers\AdminPincodeController::class, 'toggle'])->name('admin.pincodes.toggle');
Route::delete('/admin/pincodes/{id}', [App\Http\Controllers\AdminPincodeController::class, 'destroy'])->name('admin.pincodes.destroy');

Route::get('/admin/scrap-vehicles',[App\Http\Controllers\ScrapVehicleController::class, 'adminIndex'])->name('admin.scrap-vehicles.index');

Route::get('/admin/feedbacks', [FeedbackController::class, 'adminIndex'])->name('admin.feedbacks.index');
Route::post('/admin/feedbacks/{id}/toggle', [FeedbackController::class, 'toggleApproval'])->name('admin.feedbacks.toggle');

Route::get('/admin/pages', [PageController::class, 'index'])->name('admin.pages.index');
Route::get('/admin/pages/create', [PageController::class, 'create'])->name('admin.pages.create');
Route::post('/admin/pages/store', [PageController::class, 'store'])->name('admin.pages.store');
Route::get('/admin/pages/{id}/edit', [PageController::class, 'edit'])->name('admin.pages.edit');
Route::post('/admin/pages/{id}', [PageController::class, 'update'])->name('admin.pages.update');
Route::delete('/admin/pages/{id}', [PageController::class, 'destroy'])->name('admin.pages.destroy');
});

// Categories AJAX API endpoints
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\SubcategoryController;
use App\Http\Controllers\BannerController;
use App\Http\Controllers\FaqController;
use App\Http\Controllers\RewardController;

Route::prefix('api')->middleware('admin')->group(function () {
    Route::post('categories/{id}', [CategoryController::class, 'update']);
    Route::apiResource('categories', CategoryController::class)->except(['update']);

    Route::post('subcategories/{id}', [SubcategoryController::class, 'update']);
    Route::apiResource('subcategories', SubcategoryController::class)->except(['update']);

    Route::post('banners/{id}', [BannerController::class, 'update']);
    Route::post('banners/{id}/status', [BannerController::class, 'toggleStatus']);
    Route::apiResource('banners', BannerController::class)->except(['update']);

    Route::post('faqs/{id}', [FaqController::class, 'update']);
    Route::post('faqs/{id}/status', [FaqController::class, 'toggleStatus']);
    Route::apiResource('faqs', FaqController::class)->except(['update']);

    Route::get('rewards/settings', [RewardController::class, 'getSettings']);
    Route::post('rewards/settings', [RewardController::class, 'updateSettings']);
    Route::post('rewards/{id}', [RewardController::class, 'update']);
    Route::post('rewards/{id}/status', [RewardController::class, 'toggleStatus']);
    Route::apiResource('rewards', RewardController::class)->except(['update']);
});
