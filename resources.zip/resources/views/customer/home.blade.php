@extends('layouts.app')

@section('title', 'Customer Dashboard - Scrap Daddy')

@push('styles')
    @include('partials.customer.styles')
@endpush

@section('content')
@include('partials.toast')

<div class="dashboard-container">
    <div class="row g-4">
        
        @include('partials.customer.sidebar')

        <!-- Main Content -->
        <div class="col-xl-9 col-lg-9">
            @php
                $user = auth()->user();
                $recentOrders = \App\Models\Order::with('subcategory')->where('user_uuid', $user->uuid)->latest()->take(5)->get();
                $totalPickups = \App\Models\Order::where('user_uuid', $user->uuid)->count();
                $rewardPoints = $user->reward_coins ?? 0;
            @endphp
            
            <!-- DESKTOP VIEW -->
            <div class="d-none d-lg-block">
            <!-- Hero Banner -->
            @include('partials.customer.hero-banner', [
                'title' => 'Hello ' . explode(' ', trim($user->full_name))[0] . '! 👋',
                'subtitle' => 'Thanks for being a part of a cleaner and greener tomorrow.'
            ])

            <!-- Stats Grid -->
            <div class="row g-3 mb-4">
                <div class="col-12 col-md-6">
                    <div class="stat-card stat-green">
                        <div class="stat-icon"><i class="fa-solid fa-truck-fast"></i></div>
                        <div class="stat-info">
                            <h3>{{ $totalPickups }}</h3>
                            <p>Total Pickups</p>
                            <small>All time</small>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6">
                    <div class="stat-card stat-orange">
                        <div class="stat-icon"><i class="fa-solid fa-star"></i></div>
                        <div class="stat-info">
                            <h3>{{ $rewardPoints }}</h3>
                            <p>Reward Points</p>
                            <small>Available balance</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- My Pickups Horizontal List -->
            <div class="section-header">
                <h5>My Pickups</h5>
                <a href="{{ route('customer.orders') }}">View All Pickups <i class="fa-solid fa-arrow-right ms-1"></i></a>
            </div>
            
            <div class="horizontal-scroll-container">
                @forelse($recentOrders as $order)
                
                @if(in_array($order->status, ['pending', 'accepted']))
                @include('partials.customer.pickup-tracker-card', ['order' => $order])
                @else
                <!-- Past Order Card -->
                <div class="pickup-card flex-shrink-0" style="min-width: 320px;">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="d-flex gap-2 align-items-center">
                            <div class="bg-light p-2 rounded"><i class="fa-solid fa-truck text-primary"></i></div>
                            <div>
                                <h6 class="mb-0 fw-bold text-dark" style="font-size: 0.9rem;">Tata Ace - Load Assist 🙋‍♂️</h6>
                                <p class="mb-0 text-muted" style="font-size: 0.75rem;">{{ \Carbon\Carbon::parse($order->pickup_date)->format('d M Y') }}, {{ $order->pickup_time }}</p>
                            </div>
                        </div>
                        <div class="fw-bold fs-5 text-dark">₹{{ $order->total_amount ?? '0' }} <i class="fa-solid fa-chevron-right fs-6 text-muted ms-1"></i></div>
                    </div>

                    <div class="bg-light p-3 rounded-3 mb-3">
                        <div class="d-flex gap-3 mb-3">
                            <div class="d-flex flex-column align-items-center">
                                <div class="rounded-circle bg-success text-white d-flex align-items-center justify-content-center" style="width: 20px; height: 20px; font-size: 10px;"><i class="fa-solid fa-arrow-up"></i></div>
                                <div class="border-start border-2 border-secondary border-opacity-25 flex-grow-1 my-1"></div>
                                <div class="rounded-circle bg-danger text-white d-flex align-items-center justify-content-center" style="width: 20px; height: 20px; font-size: 10px;"><i class="fa-solid fa-arrow-down"></i></div>
                            </div>
                            <div class="d-flex flex-column justify-content-between w-100">
                                <div>
                                    <div class="text-muted" style="font-size: 0.75rem;">ScrapDaddy User &bull;</div>
                                    <div class="text-dark text-truncate" style="font-size: 0.8rem; max-width: 200px;">{{ $order->pickup_location }}</div>
                                </div>
                                <div class="mt-3">
                                    <div class="text-muted" style="font-size: 0.75rem;">Scrapdaddy Hub</div>
                                    <div class="text-dark text-truncate" style="font-size: 0.8rem; max-width: 200px;">Bengaluru</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3 d-flex flex-wrap gap-2">
                        @if($order->coins_earned > 0)
                            <span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1"><i class="fa-solid fa-arrow-trend-up"></i> +{{ $order->coins_earned }} Coins Earned</span>
                        @endif
                        @if($order->coins_redeemed > 0)
                            <span class="badge bg-warning-subtle text-warning border border-warning-subtle px-2 py-1" style="color: #ed6c02 !important;"><i class="fa-solid fa-gift"></i> -{{ $order->coins_redeemed }} Coins Redeemed (Saved ₹{{ $order->discount_applied }})</span>
                        @endif
                    </div>
                    
                    <div>
                        @if($order->status == 'completed')
                            <span class="badge bg-success bg-opacity-10 text-success border border-success px-3 py-2 rounded-pill"><i class="fa-solid fa-check-circle me-1"></i> COMPLETED</span>
                        @else
                            <span class="badge bg-danger bg-opacity-10 text-danger border border-danger px-3 py-2 rounded-pill"><i class="fa-solid fa-xmark me-1"></i> CANCELLED</span>
                        @endif
                    </div>
                </div>
                @endif
                
                @empty
                <div class="w-100 text-center py-5 text-muted">
                    <i class="fa-solid fa-box-open fa-3x mb-3 opacity-50"></i>
                    <p>No recent pickups found. Schedule one today!</p>
                </div>
                @endforelse
            </div>

            <!-- Quick Actions -->
            <div class="section-header">
                <h5>Quick Actions</h5>
            </div>
            <div class="quick-actions-row">
                <div class="quick-action-card">
                    <div class="quick-action-icon bg-success bg-opacity-10 text-success"><i class="fa-solid fa-location-dot"></i></div>
                    <div>
                        <h6>Track Pickup</h6>
                        <p>Track your pickup status</p>
                    </div>
                </div>
                <div class="quick-action-card" onclick="window.location.href='{{ route('customer.rewards') }}'" style="cursor: pointer;">
                    <div class="quick-action-icon bg-success bg-opacity-10 text-success"><i class="fa-solid fa-gift"></i></div>
                    <div>
                        <h6>Reward Store</h6>
                        <p>Redeem your points</p>
                    </div>
                </div>
                <div class="quick-action-card" onclick="window.location.href='{{ route('customer.refer') }}'" style="cursor: pointer;">
                    <div class="quick-action-icon bg-success bg-opacity-10 text-success"><i class="fa-solid fa-users"></i></div>
                    <div>
                        <h6>Refer & Earn</h6>
                        <p>Invite friends & earn</p>
                    </div>
                </div>
                <div class="quick-action-card" onclick="window.location.href='{{ route('customer.support') }}'">
                    <div class="quick-action-icon bg-success bg-opacity-10 text-success"><i class="fa-solid fa-headset"></i></div>
                    <div>
                        <h6>Help Center</h6>
                        <p>Get support</p>
                    </div>
                </div>
            </div>
            </div> <!-- End Desktop View -->

            <!-- MOBILE VIEW -->
            <div class="d-block d-lg-none pb-5" style="background-color: #f8f9fa; min-height: 100vh; margin: -30px -15px 0 -15px;">
                <!-- Blue Header Section -->
                <div class="pt-4 pb-5 px-3 mb-4" style="background: linear-gradient(135deg, #1a4275 0%, #295b9d 100%); border-bottom-left-radius: 20px; border-bottom-right-radius: 20px;">
                    <!-- Header Section -->
                    <div class="d-flex justify-content-between align-items-center mb-4 mt-2">
                        <div class="d-flex align-items-center gap-3">
                            <div class="position-relative">
                                <img src="https://img.freepik.com/free-psd/3d-illustration-person-with-sunglasses_23-2149436188.jpg?w=250" alt="Avatar" class="rounded-circle border border-2 border-white shadow-sm" style="width: 50px; height: 50px; object-fit: cover;">
                                <span class="position-absolute bottom-0 end-0 bg-success border border-2 border-white rounded-circle" style="width: 14px; height: 14px;"></span>
                            </div>
                            <div>
                                <h5 class="mb-0 fw-bold text-white" style="font-size: 1.1rem;">Hello {{ explode(' ', trim($user->full_name))[0] }}</h5>
                                <small class="text-white-50" style="font-size: 0.75rem;">Recycle Today, Earn Tomorrow ♻</small>
                            </div>
                        </div>
                    </div>

                    <!-- Location Box -->
                    <div class="rounded-4 p-3 shadow-sm border border-white border-opacity-10 d-flex align-items-center gap-3" style="background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(10px);">
                        <div class="text-white"><i class="fa-solid fa-location-dot fs-5"></i></div>
                        <div>
                            <h6 class="mb-0 fw-bold text-white" style="font-size: 0.95rem;" id="locationTextMobile2">{{ $user->location ?? 'Detecting Location...' }}</h6>
                            <small class="text-white-50" style="font-size: 0.75rem;">{{ $user->location ? 'Your saved location' : 'Finding your location' }}</small>
                        </div>
                    </div>
                </div>

                <div class="px-3" style="margin-top: -30px; position: relative; z-index: 10;">



                <style>
                    .sd-track { position: relative; padding: 16px 0 8px; }
                    .sd-track-line { position: absolute; left: 12.5%; right: 12.5%; top: 36px; height: 3px; border-radius: 2px;
                        background: repeating-linear-gradient(90deg, #d3d3d3 0 8px, transparent 8px 16px); }
                    .sd-track-fill { position: absolute; left: 0; top: 0; height: 3px; width: 0; border-radius: 2px; background: #4CAF50;
                        transition: width 2s cubic-bezier(.22, 1, .36, 1); }
                    .sd-track-fill.is-cancelled { background: #dc3545; }
                    .sd-track-steps { position: relative; z-index: 2; display: flex; }
                    .sd-step { flex: 1; min-width: 0; text-align: center; padding: 0 2px; }
                    .sd-ic { width: 42px; height: 42px; margin: 0 auto; display: flex; align-items: center; justify-content: center; }
                    .sd-dot { width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center;
                        background: #f5f5f5; color: #9e9e9e; font-size: .85rem; }
                    .sd-dot.is-check { background: #fff; border: 2px solid #4CAF50; color: #4CAF50; }
                    .sd-dot.is-cancelled { background: #fff; border: 2px solid #dc3545; color: #dc3545; }
                    .sd-truck { width: 40px; height: auto; background: #fff; border-radius: 8px; animation: sdTruckIn .6s ease-out both; }
                    @keyframes sdTruckIn { from { transform: translateX(-14px); opacity: 0; } to { transform: none; opacity: 1; } }
                    .sd-title { font-size: .75rem; font-weight: 700; margin-top: 8px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
                    .sd-sub { font-size: .625rem; color: #8a8a8a; line-height: 1.25; margin-top: 4px; }
                    .sd-info { background: #f3f9ff; border-radius: 16px; padding: 16px; }
                    .sd-info h6 { font-size: 1rem; font-weight: 700; color: #222; margin: 0 0 10px; }
                    .sd-info p { font-size: .75rem; color: #2f3943; margin: 0; line-height: 1.4; }
                </style>
                <script>
                    document.addEventListener('DOMContentLoaded', function () {
                        document.querySelectorAll('.sd-track').forEach(function (t) {
                            var fill = t.querySelector('.sd-track-fill');
                            requestAnimationFrame(function () { fill.style.width = (t.dataset.fill || 0) + '%'; });
                        });
                    });
                </script>
                <!-- Dynamic Pickups Section (Horizontally Scrollable) -->
                @php
                    $activeOrders = $recentOrders->whereIn('status', ['pending', 'accepted', 'assigned']);
                @endphp
                @if($activeOrders->count() > 0)
                <div class="d-flex overflow-x-auto gap-3 pb-3 mb-4" style="scroll-snap-type: x mandatory; scrollbar-width: none; -ms-overflow-style: none;">
                    @foreach($activeOrders as $order)
                    <div class="bg-white rounded-4 p-3 p-sm-4 shadow-sm border border-light flex-shrink-0" style="width: 100%; min-width: 300px; max-width: 100%; scroll-snap-align: start;">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <div class="d-flex align-items-center gap-2">
                                <div class="bg-success bg-opacity-10 text-success rounded-circle d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                                    <i class="fa-solid fa-truck"></i>
                                </div>
                                <h6 class="mb-0 fw-bold text-dark">
                                    @if($order->status == 'completed')
                                        Pickup Completed
                                    @elseif($order->status == 'cancelled')
                                        Pickup Cancelled
                                    @else
                                        Pickup Requested
                                    @endif
                                </h6>
                            </div>
                            <span class="badge {{ $order->status == 'pending' ? 'bg-warning' : ($order->status == 'completed' ? 'bg-success' : ($order->status == 'cancelled' ? 'bg-danger' : 'bg-primary')) }} rounded-pill" style="font-size: 0.7rem;">{{ ucfirst($order->status) }}</span>
                        </div>

                        <!-- Stepper Section (mirrors the Android app tracker) -->
                        @php
                            $st = $order->status;
                            $isCancelled = ($st === 'cancelled');
                            $trackStep = $st === 'completed' ? 3 : ($st === 'assigned' ? 2 : ($st === 'accepted' ? 1 : 0));
                            $trackFill = $isCancelled ? 100 : round($trackStep / 3 * 100);
                            $trackSteps = [
                                ['title' => 'Submitted', 'sub' => $order->created_at ? $order->created_at->format('d M, h:i A') : 'Waiting', 'icon' => 'fa-solid fa-check', 'color' => '#4CAF50'],
                                ['title' => 'Confirmed', 'sub' => $trackStep >= 1 ? 'Confirmed' : 'Waiting confirmation', 'icon' => 'fa-regular fa-clock', 'color' => '#FFB300'],
                                ['title' => 'Assigned', 'sub' => $trackStep >= 2 ? 'Driver Assigned' : 'Pending Driver assignment', 'icon' => 'fa-solid fa-user', 'color' => '#5A5A5A'],
                                ['title' => 'Completed', 'sub' => $isCancelled ? 'Cancelled' : ($trackStep >= 3 ? 'Done' : 'Pending Delivery completion'), 'icon' => 'fa-solid fa-flag', 'color' => '#5A5A5A'],
                            ];
                        @endphp
                        <div class="sd-track" data-fill="{{ $trackFill }}">
                            <div class="sd-track-line"><div class="sd-track-fill {{ $isCancelled ? 'is-cancelled' : '' }}"></div></div>
                            <div class="sd-track-steps">
                                @foreach($trackSteps as $i => $s)
                                    <div class="sd-step">
                                        <div class="sd-ic">
                                            @if(!$isCancelled && $i === $trackStep)
                                                <img src="{{ asset('green_truck.png') }}" alt="Truck" class="sd-truck">
                                            @elseif($isCancelled)
                                                <span class="sd-dot is-cancelled"><i class="{{ $i === 3 ? 'fa-solid fa-xmark' : $s['icon'] }}"></i></span>
                                            @else
                                                <span class="sd-dot {{ $i === 0 ? 'is-check' : '' }}"><i class="{{ $s['icon'] }}"></i></span>
                                            @endif
                                        </div>
                                        <div class="sd-title" style="color: {{ $isCancelled ? '#dc3545' : $s['color'] }};">{{ $s['title'] }}</div>
                                        <div class="sd-sub">{{ $s['sub'] }}</div>
                                    </div>
                                @endforeach
                            </div>
                        </div>

                        @if($order->status == 'pending')
                        <div class="sd-info">
                            <h6>Confirming your request...</h6>
                            <p>
                                Please wait while we confirm your pickup request. This usually takes 15-30 minutes.
                            </p>
                        </div>
                        @elseif($order->status == 'completed')
                        <div class="rounded-4 p-3 bg-success bg-opacity-10 border border-success">
                            <h6 class="fw-bold text-success mb-1">Pickup Successful!</h6>
                            <p class="text-success mb-0" style="font-size: 0.8rem;">You earned rewards for this pickup.</p>
                        </div>
                        @elseif($order->status == 'cancelled')
                        <div class="rounded-4 p-3 bg-danger bg-opacity-10 border border-danger">
                            <h6 class="fw-bold text-danger mb-1">Pickup Cancelled</h6>
                            <p class="text-danger mb-0" style="font-size: 0.8rem;">This pickup request was cancelled.</p>
                        </div>
                        @else
                        <div class="rounded-4 p-3" style="background-color: #f8f9fa;">
                            <h6 class="fw-bold text-dark mb-1">Scheduled for Pickup</h6>
                            <p class="text-muted mb-0" style="font-size: 0.8rem;">Your pickup is scheduled for {{ \Carbon\Carbon::parse($order->pickup_date)->format('d M') }}, {{ $order->pickup_time }}.</p>
                        </div>
                        @endif
                    </div>
                    @endforeach
                </div>
                <!-- Hide scrollbar for webkit browsers via style block injected quickly -->
                <style>
                    .overflow-x-auto::-webkit-scrollbar { display: none; }
                </style>
                @else
                <!-- Fallback Empty State -->
                <div class="bg-white rounded-4 p-4 mb-4 shadow-sm border border-light text-center">
                    <i class="fa-solid fa-box-open text-muted fs-1 mb-3 opacity-50"></i>
                    <h6 class="fw-bold text-dark">No Recent Pickups</h6>
                    <p class="text-muted small mb-3">You don't have any active pickup requests right now.</p>
                    <a href="{{ route('customer.orders.create') ?? '#' }}" class="btn rounded-pill text-white fw-bold px-4" style="background: var(--primary-green, #3D8B4D); font-size: 0.85rem;">Schedule a Pickup</a>
                </div>
                @endif

                <!-- Dynamic Banners -->
                @php
                    $banners = \App\Models\Banner::where('status', 1)->where('type', 'mobile')->get();
                    if ($banners->isEmpty()) {
                        $banners = \App\Models\Banner::where('status', 1)->get();
                    }
                @endphp
                
                @if($banners->count() > 0)
                <div id="mobileBannerCarousel" class="carousel slide mb-4" data-bs-ride="carousel" data-bs-interval="4000">
                    @if($banners->count() > 1)
                    <div class="carousel-indicators" style="bottom: -25px;">
                        @foreach($banners as $index => $banner)
                            <button type="button" data-bs-target="#mobileBannerCarousel" data-bs-slide-to="{{ $index }}" class="{{ $index == 0 ? 'active' : '' }}" aria-current="{{ $index == 0 ? 'true' : 'false' }}" style="width: 8px; height: 8px; border-radius: 50%; background-color: #4A9A58;"></button>
                        @endforeach
                    </div>
                    @endif
                    <div class="carousel-inner rounded-4 shadow-sm" style="background: #ffffff; overflow: hidden;">
                        @foreach($banners as $index => $banner)
                        <div class="carousel-item {{ $index == 0 ? 'active' : '' }}">
                            <div class="position-relative w-100">
                                @if($banner->uploads)
                                    <a href="{{ route('categories.explore') }}" class="d-block w-100">
                                        <img src="{{ asset($banner->uploads) }}" class="d-block w-100 rounded-4" style="object-fit: cover; max-height: 220px; width: 100%;" alt="{{ $banner->title }}">
                                    </a>
                                @else
                                    <div class="p-4 w-100 position-relative text-center" style="background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%);">
                                        <h3 class="fw-bolder mb-2" style="color: #2e3025; font-size: 1.3rem; line-height: 1.2;">
                                            {{ $banner->title }}
                                        </h3>
                                        @if($banner->short_description)
                                            <p class="text-muted small mb-3">{{ $banner->short_description }}</p>
                                        @endif
                                        <a href="{{ route('categories.explore') }}" class="btn btn-sm rounded-pill text-white px-3 fw-bold" style="background: #5b7b3b; font-size: 0.75rem;">
                                            Recycle Now <i class="fa-solid fa-arrow-right ms-1"></i>
                                        </a>
                                    </div>
                                @endif
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
                @else
                <!-- Static Fallback Promotional Banner -->
                <div class="rounded-4 overflow-hidden position-relative mb-4" style="background: #f4f3ed; height: 200px;">
                    <div class="p-4 w-75 position-relative" style="z-index: 2;">
                        <h3 class="fw-bolder mb-3" style="color: #2e3025; font-size: 1.5rem; line-height: 1.2;">
                            Turn Your Scrap<br><span class="text-success">Into Rewards</span>
                        </h3>
                        <button class="btn btn-sm rounded-pill text-white px-3 fw-bold" style="background: #5b7b3b; font-size: 0.75rem;">
                            Recycle Now <i class="fa-solid fa-arrow-right ms-1"></i>
                        </button>
                    </div>
                    <!-- Absolute positioned decoration elements to mimic the mockup -->
                    <i class="fa-solid fa-coins text-warning position-absolute" style="font-size: 1.5rem; top: 15%; left: 10%; opacity: 0.8;"></i>
                    <i class="fa-solid fa-coins text-warning position-absolute" style="font-size: 2rem; top: 10%; right: 40%; opacity: 0.9;"></i>
                    <div class="position-absolute" style="right: 5%; bottom: -10%; z-index: 1; opacity: 0.9;">
                        <i class="fa-solid fa-box-open text-muted" style="font-size: 8rem; opacity: 0.1;"></i>
                    </div>
                </div>
                @endif

                <!-- Dynamic Categories -->
                @php
                    $mobileCategories = \App\Models\Category::where('status', 1)->take(6)->get();
                    // Saved PIN code of the user: when it is outside the service area, show "not available" instead of categories
                    $svcPin = preg_match('/^[1-9][0-9]{5}$/', (string) ($user->pin_code ?? '')) ? $user->pin_code : null;
                    $svcOk = !$svcPin || \App\Models\ServicePincode::isServiceable($svcPin);
                @endphp
                @if(!$svcOk)
                    <div class="bg-white rounded-4 shadow-sm border border-light text-center p-4 mt-4 mb-4">
                        <div class="rounded-circle bg-success bg-opacity-10 d-inline-flex align-items-center justify-content-center mb-3" style="width: 64px; height: 64px;">
                            <i class="fa-solid fa-location-crosshairs text-success fs-3"></i>
                        </div>
                        <h5 class="fw-bold text-dark mb-2">Service not available</h5>
                        <p class="text-muted mb-3" style="font-size: .9rem;">We don't pick up scrap in PIN code {{ $svcPin }} yet. We are expanding fast - please check back soon.</p>
                        <a href="{{ route('customer.profile') }}" class="btn btn-sm rounded-pill px-3 fw-bold" style="border: 1.5px solid #4A9A58; color: #4A9A58;">Change my location</a>
                    </div>
                @else
                <div class="d-flex justify-content-between align-items-center mb-3 mt-5">
                    <h5 class="fw-bold text-dark mb-0">Categories</h5>
                    <a href="{{ url('/explore-categories') }}" class="text-success text-decoration-none fw-bold" style="font-size: 0.85rem;">View All <i class="fa-solid fa-chevron-right ms-1" style="font-size: 0.7rem;"></i></a>
                </div>
                <div class="row g-3 pb-4">
                    @forelse($mobileCategories as $category)
                    <div class="col-4">
                        <a href="{{ route('category.show', $category->uuid) }}" class="text-decoration-none">
                            <div class="bg-white p-2 rounded-4 shadow-sm text-center border border-light h-100 d-flex flex-column justify-content-center align-items-center transition-all" style="min-height: 110px;">
                                @if($category->image)
                                    <img src="{{ asset($category->image) }}" alt="{{ $category->title }}" style="width: 50px; height: 50px; object-fit: contain; margin-bottom: 12px;">
                                @else
                                    <i class="fa-solid fa-box-open text-muted fs-2 mb-2"></i>
                                @endif
                                <h6 class="fw-bold text-dark mb-0" style="font-size: 0.8rem; line-height: 1.2;">{{ $category->title }}</h6>
                            </div>
                        </a>
                    </div>
                    @empty
                    <div class="col-12 text-center text-muted">
                        <small>No categories available.</small>
                    </div>
                    @endforelse
                </div>
                @endif

                <!-- How it works -->
                <div class="mb-4 mt-2">
                    <h5 class="fw-bold text-dark mb-3">How it works</h5>
                    <div class="d-flex justify-content-between align-items-center bg-white p-3 rounded-4 shadow-sm border border-light">
                        <!-- Step 1 -->
                        <div class="text-center position-relative">
                            <div class="rounded-circle bg-success bg-opacity-10 d-flex align-items-center justify-content-center mx-auto mb-2 shadow-sm" style="width: 45px; height: 45px;">
                                <i class="fa-solid fa-location-dot text-success fs-5"></i>
                            </div>
                            <div class="fw-bold text-dark" style="font-size: 0.65rem;">Location</div>
                        </div>
                        <i class="fa-solid fa-chevron-right text-muted" style="font-size: 0.6rem;"></i>
                        <!-- Step 2 -->
                        <div class="text-center position-relative">
                            <div class="rounded-circle bg-success bg-opacity-10 d-flex align-items-center justify-content-center mx-auto mb-2 shadow-sm" style="width: 45px; height: 45px;">
                                <i class="fa-solid fa-sack-dollar text-success fs-5"></i>
                            </div>
                            <div class="fw-bold text-dark" style="font-size: 0.65rem;">Add Scrap</div>
                        </div>
                        <i class="fa-solid fa-chevron-right text-muted" style="font-size: 0.6rem;"></i>
                        <!-- Step 3 -->
                        <div class="text-center position-relative">
                            <div class="rounded-circle bg-success bg-opacity-10 d-flex align-items-center justify-content-center mx-auto mb-2 shadow-sm" style="width: 45px; height: 45px;">
                                <i class="fa-solid fa-truck text-success fs-5"></i>
                            </div>
                            <div class="fw-bold text-dark" style="font-size: 0.65rem;">Schedule</div>
                        </div>
                        <i class="fa-solid fa-chevron-right text-muted" style="font-size: 0.6rem;"></i>
                        <!-- Step 4 -->
                        <div class="text-center position-relative">
                            <div class="rounded-circle bg-warning bg-opacity-10 d-flex align-items-center justify-content-center mx-auto mb-2 shadow-sm" style="width: 45px; height: 45px;">
                                <i class="fa-solid fa-coins text-warning fs-5"></i>
                            </div>
                            <div class="fw-bold text-dark" style="font-size: 0.65rem;">Earn Rewards</div>
                        </div>
                    </div>
                </div>

                <!-- Refer a Friend -->
                <div id="referFriendCard" role="button" tabindex="0" style="cursor:pointer;" class="bg-white p-3 rounded-4 shadow-sm border border-light d-flex align-items-center justify-content-between mb-4">
                    <div class="d-flex align-items-center gap-3">
                        <div class="rounded-circle bg-success bg-opacity-10 d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                            <i class="fa-solid fa-users text-success fs-4"></i>
                        </div>
                        <div>
                            <h6 class="mb-0 fw-bold text-dark" style="font-size: 1rem;">Refer a Friend</h6>
                            <small class="text-muted">Invite friends & earn rewards</small>
                        </div>
                    </div>
                    <i class="fa-solid fa-chevron-right text-success fw-bold"></i>
                </div>
                </div> <!-- End Main mobile content wrapper -->
            </div> <!-- End Mobile View -->

        <!-- Right Sidebar Removed -->

    </div>
</div>
@push('scripts')
<script>
    (function () {
        const card = document.getElementById('referFriendCard');
        if (!card) return;
        const share = async () => {
            const data = { title: 'Join me on ScrapDaddy', text: 'Sell your scrap from home at the best price with ScrapDaddy!', url: window.location.origin };
            try {
                if (navigator.share) { await navigator.share(data); return; }
                await navigator.clipboard.writeText(data.text + ' ' + data.url);
                if (window.sdToast) sdToast('Invite link copied. Share it with your friends!');
            } catch (e) { /* user cancelled */ }
        };
        const go = () => { window.location.href = "{{ route('customer.refer') }}"; };
        card.addEventListener('click', go);
        card.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
    })();
</script>
@endpush
@endsection